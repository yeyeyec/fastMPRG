library(cubature)
library(Rcpp)
library(RcppArmadillo)

erf <- function(vi){
  f <- function(y){2/sqrt(pi)*exp(-y^2)}
  return (integrate(f,0,vi)$value)
}


func_chi_uni <- function(R_vivj,freedom = 1,min = 0, upper = 1){

  integrate_func <-function(v,rd = freedom,R = R_vivj,mins = min,uppers = upper){
   (
     (qchisq(0.5*(1+erf(v[1]/sqrt(2))),df = rd) - rd) /sqrt(2*rd)*
      (qunif(0.5*(1+erf(v[2]/sqrt(2))) , min = mins, max = uppers)-0.5*(uppers+mins))
      / sqrt((uppers-mins)^2/12) *
       (1/(2*pi*sqrt(1-R^2))) *
       exp(-(v[1]^2-2*R*v[1]*v[2]+v[2]^2)/(2*(1-R^2)))
   )
  }

  result <-adaptIntegrate(integrate_func,c(-5,-5),c(5,5))
  return (result$integral)
}


func_chi_nor <- function(R_vivj,freedom = 1,mean = 0, sigma = 1){

  integrate_func <-function(v,rd = freedom,R = R_vivj,means = mean,sigmas = sigma){
    (
      (qchisq(0.5*(1+erf(v[1]/sqrt(2))),df = rd) - rd) /sqrt(2*rd)*
        (qnorm(0.5*(1+erf(v[2]/sqrt(2))) , mean = means, sd = sigmas)- means)/ sigmas *
        (1/(2*pi*sqrt(1-R^2))) *
        exp(-(v[1]^2-2*R*v[1]*v[2]+v[2]^2)/(2*(1-R^2)))
    )
  }

  result <-adaptIntegrate(integrate_func,c(-5,-5),c(5,5))
  return (result$integral)
}


func_nor_uni <- function(R_vivj,mean = 0, sigma = 1,min = 0, upper = 1){

  integrate_func <-function(v,means = mean,sigmas = sigma,R = R_vivj,mins = min,uppers = upper){
    (
      (qnorm(0.5*(1+erf(v[1]/sqrt(2))) , mean = means, sd = sigmas)- means)/ sigmas*
        (qunif(0.5*(1+erf(v[2]/sqrt(2))) , min = mins, max = uppers)-0.5*(uppers+mins))
      / sqrt((uppers-mins)^2/12) *
        (1/(2*pi*sqrt(1-R^2))) *
        exp(-(v[1]^2-2*R*v[1]*v[2]+v[2]^2)/(2*(1-R^2)))
    )
  }

  result <-adaptIntegrate(integrate_func,c(-5,-5),c(5,5))
  return (result$integral)
}


get_R_vivj_chi_unif <- function(R_zizj,fdnum){
  R_vivj = 0
  if(abs(R_zizj) > func_chi_uni(0.98,fdnum))
  {
    stop("we can't handle this Related Coefficient","\n",call.=FALSE)
  }

  if(R_zizj>0)
  {
    start_point = 0
    end_point = 0.98
  }

  while(R_zizj > 0)
  {
    mid<-(start_point+end_point)/2
    t <- R_zizj-func_chi_uni(mid,freedom = fdnum)
    if(abs(t) < 0.005){
      return(mid)
    }
    if(t > 0){
      start_point = mid
    }
    if(t<0){
      end_point = mid
    }
  }

  if(R_zizj<0)
  {
    start_point = -0.98
    end_point = 0
  }

  while(R_zizj < 0)
  {
    mid<-(start_point+end_point)/2
    t <- R_zizj-func_chi_uni(mid,freedom = fdnum)
    if(abs(t) < 0.005){
      return(mid)
    }
    if(t > 0){
      start_point = mid
    }
    if(t<0){
      end_point = mid
    }
  }
  return(R_vivj)
}


get_R_vivj_chi_nor <- function(R_zizj,fdnum){
  R_vivj = 0
  if(abs(R_zizj) > func_chi_nor(0.98,fdnum))
  {
    stop("we can't handle this Related Coefficient","\n",call.=FALSE)
  }

  if(R_zizj>0)
  {
    start_point = 0
    end_point = 0.98
  }

  while(R_zizj > 0)
  {
    mid<-(start_point + end_point)/2
    t <- R_zizj - func_chi_nor(mid,freedom = fdnum)
    if(abs(t) < 0.005){
      return(mid)
    }
    if(t > 0){
      start_point = mid
    }
    if(t<0){
      end_point = mid
    }
  }

  if(R_zizj<0)
  {
    start_point = -0.98
    end_point = 0
  }

  while(R_zizj < 0)
  {
    mid<-(start_point+end_point)/2
    t <- R_zizj-func_chi_nor(mid,freedom = fdnum)
    if(abs(t) < 0.005){
      return(mid)
    }
    if(t > 0){
      start_point = mid
    }
    if(t<0){
      end_point = mid
    }
  }
  return(R_vivj)
}


get_R_vivj_nor_unif <- function(R_zizj){
  R_vivj = 0
  if(abs(R_zizj) > func_nor_uni(0.98))
  {
    stop("we can't handle this Related Coefficient","\n",call.=FALSE)
  }

  if(R_zizj>0)
  {
    start_point = 0
    end_point = 0.98
  }

  while(R_zizj > 0)
  {
    mid<-(start_point+end_point)/2
    t <- R_zizj-func_nor_uni(mid)
    if(abs(t) < 0.005){
      return(mid)
    }
    if(t > 0){
      start_point = mid
    }
    if(t<0){
      end_point = mid
    }
  }

  if(R_zizj<0)
  {
    start_point = -0.98
    end_point = 0
  }

  while(R_zizj < 0)
  {
    mid<-(start_point+end_point)/2
    t <- R_zizj-func_nor_uni(mid)
    if(abs(t) < 0.005){
      return(mid)
    }
    if(t > 0){
      start_point = mid
    }
    if(t<0){
      end_point = mid
    }
  }
  return(R_vivj)
}

#' The Data Generation of Chi-square Distribution and Uniform Distribution 
#' @description 
#' The generation of two related sequences 
#' follows chi-square distribution and uniform distribution respectively
#' @param n number of generation data from each distribution
#' @param corr a number, the correlation between the two distribution
#' @param rd degrees of freedom of chi square distribution
#' @param min the minimum number of uniform distribution
#' @param max the maximum number of uniform distribution
#'
#' @return a matrix which the first column obey chi-square distribution and the second column obey uniform distribution
#' @export
#'
#' @examples
#' my_mat = chi_unif(20000,0.4,rd = 5, min = 2,max = 5)
#' new_mat = as.data.frame(my_mat)
#' cor(new_mat)
#' cov(new_mat)
chi_unif<-function(n,corr,rd = 1,min = 0, max = 1 ){

  correlation = get_R_vivj_chi_unif(R_zizj = corr,fdnum = rd)
  A = matrix(c(1,correlation,correlation,1),nrow = 2 , ncol = 2 ,byrow =T)
  test_mat = fastnorm(A,n,mu = rep(0,2),sigma = rep(1,2))

  for (i in 1:n) {
    test_mat[i,1] = qchisq(0.5*(1+erf(test_mat[i,1]/sqrt(2))),df = rd)
  }

  for(i in 1:n){
    test_mat[i,2] = qunif(0.5*(1+erf(test_mat[i,2]/sqrt(2))),min = min,max = max)
  }

  return(test_mat)
}


#' The Data Generation of Chi-square Distribution and Normal Distribution 
#' @description 
#' The generation of two related sequences 
#' follows chi-square distribution and normal distribution respectively
#' @param n number of generation data from each distribution
#' @param corr a number, the correlation between the two distribution
#' @param rd degrees of freedom of chi square distribution
#' @param mean the mean of normal distribution
#' @param sigma the standard deviation of normal distribution 
#'
#' @return a matrix which the first column obey chi-square distribution and the second column obey normal distribution
#' @export
#'
#' @examples
#' my_mat = chi_nor(20000,0.6,rd = 5,mean = 3,sigma = 2)
#' new_mat = as.data.frame(my_mat)
#' cor(new_mat)
#' cov(new_mat)
#' 
chi_nor<-function(n,corr,rd = 1,mean = 0, sigma = 1 ){

  correlation = get_R_vivj_chi_nor(R_zizj = corr,fdnum = rd)
  A = matrix(c(1,correlation,correlation,1),nrow = 2 , ncol = 2 ,byrow =T)
  test_mat = fastnorm(A,n,mu = rep(0,2),sigma = rep(1,2))

  for (i in 1:n) {
    test_mat[i,1] = qchisq(0.5*(1+erf(test_mat[i,1]/sqrt(2))),df = rd)
  }

  for(i in 1:n){
    test_mat[i,2] = qnorm(0.5*(1+erf(test_mat[i,2]/sqrt(2))),mean = mean,sd = sigma)
  }

  return(test_mat)
}


#' The Data Generation of Normal Distribution and Uniform Distribution
#' 
#' @description 
#' The generation of two related sequences 
#' follows normal distribution and uniform distribution respectively
#' 
#' @param n number of generation data from each distribution
#' @param corr a number, the correlation between the two distribution
#' @param mean the mean of normal distribution
#' @param sigma the standard deviation of normal distribution 
#' @param min the minimum number of uniform distribution
#' @param max the maximum number of uniform distribution
#'
#' @return a matrix which the first column obey normal distribution, and the second column obey uniform distribution
#' @export 
#'
#' @examples
#' my_mat = nor_unif(20000,0.9,mean = 3,sigma = 2,min = 2,max = 3)
#' new_mat = as.data.frame(my_mat)
#' cor(new_mat)
#' cov(new_mat)
#' 
nor_unif<-function(n,corr,mean = 0, sigma = 1,min = 0,max = 1 ){
  correlation = get_R_vivj_nor_unif(R_zizj = corr)
  A = matrix(c(1,correlation,correlation,1),nrow = 2 , ncol = 2 ,byrow =T)
  test_mat = fastnorm(A,n,mu = rep(0,2),sigma = rep(1,2))

  for(i in 1:n){
    test_mat[i,1] = qnorm(0.5*(1+erf(test_mat[i,1]/sqrt(2))),mean = mean,sd = sigma)
  }

  for(i in 1:n){
    test_mat[i,2] = qunif(0.5*(1+erf(test_mat[i,2]/sqrt(2))),min = min,max = max)
  }

  return(test_mat)
}


#' Calculate the Pearson correlation coefficient of each variables.
#'
#' @description
#' `corr` returns the Pearson correlation coefficient matrix to detect
#' whether our simulated data meet the required correlation structure.
#' @usage corr(data)
#' @param data The data generated by our methods (return values).
#' @return A Pearson Correlation Coefficient Matrix.
#' @export 
#' @examples 
#' A = ARStructure(0.9,5)
#' a = fastunif(A,50000)
#' corr(a)
corr <- function(data) {
  return(cor(data,method = 'pearson'))
}

#' Draw the histogram of each columns of our data.
#'
#' @description
#' `draw_hist` returns a ggplot2 figure with histogram and theoretical density curve
#' to detect whether our generated data meet the required marginal distribution shape.
#' @usage draw_hist(df,col,bin,type,xlim = c(0,1))
#' @param df The data generated by our methods (return values).
#' @param col The columns number of certain data you want to plot. Starts from 1.
#' @param bin The number of bins you want to display in your histogram.
#' @param type The theoretical distribution name. This parameter only can be processed within 5 values right now:
#' 'norm','unif','exp','beta', 'chi-square' and 'LN'.
#' @param xlim To limit the display range of horizontal axis. Default is (0,1), which means only display the generated data from 0 to 1.
#' @return A histogram with theoretical density curve.
#' @export 
#' @examples 
#' A = ARStructure(0.9,5)
#' a = fastunif(A,50000)
#' draw_hist(a,1,100,'unif')
draw_hist <- function(df, col, bin,type,xlim = c(0,1)) {
  if (type=='unif'){
    dist = 'dunif'
    para = c(0,1)
  }else if (type == 'norm'){
    dist = 'dnorm'
    para = c(mean(df[,col]),var(df[,col]))
  }else if (type == 'exp'){
    dist = 'dexp'
    para = 1/mean(df[,col])
  }else if (type == 'beta'){
    dist = 'dbeta'
    para = c(mean(df[,col])/(1-mean(df[,col])),1)
  }else if (type == 'lnorm'){
    dist = 'dlnorm'
    para = c(mean(log(df[,col])),var(log(df[,col])))
  }else {
    dist = 'dchisq'
    para = round(mean(df[,col]))
  }
  library(ggplot2)
  fig = (
    ggplot(data = as.data.frame(df[,col]))
    +geom_histogram(aes(x = df[,col],y = after_stat(density)),bins = bin, alpha = 0.5,color = 'black')
    +xlim(xlim[1],xlim[2])
    +theme_bw(16)
    +labs(x = 'Sample',y = 'Density')
    +theme(axis.title = element_text(face="bold"))
    +stat_function(fun = get(dist),args = para,n = 50000,color = "red")
  )
  return(fig)
}
