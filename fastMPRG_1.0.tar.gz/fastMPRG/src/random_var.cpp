#include <iostream>
#include <math.h>
#include <cmath>
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace arma;
using namespace Rcpp;
using namespace std;

//' Generate Multivariate Normal Distribuion Data Follow the Given Correlation Structure.
//' @description 
//' This function implements a fast pseudo random number generator
//' for a multivariate normal distribution where every marginal
//' @param rela_mat the desired correlation matrix structure you want the generated data follow. This matrix must be positive definite.
//' @param row the observed sample size you want to generate.
//' @param mu a vector contain the respective normal distribution mean
//' @param sigma a vector contain the respective normal distribution standard deviation
//' @return a matrix which every column is a data from one kind normal distribution
//' @export 
//' @examples
//' A = ARStructure(0.9,5)
//' fastnorm(rela_mat = A,row = 100,mu = rep(0,5),sigma = rep(1,5))
// [[Rcpp::export]]
arma::mat fastnorm(arma::mat rela_mat,int row, arma::vec mu ,arma::vec sigma){
  arma::mat A = arma::randn<arma::mat>(row, rela_mat.n_cols);
  arma::mat L;
  bool success = chol(L, rela_mat);
  if (!success) {
    Rcpp::Rcout << "Error: Matrix is not positive definite." << std::endl;
  }
  arma::mat B = A*L;
  B = B*diagmat(sigma);
  B = B.t();
  B.each_col([&](arma::vec& col) {
    col += mu;
  });
  return B.t();
}

double get_h_unif(double a, double b,double x) {
  //return a + (b-a)*(1+erf(x))/2;
  //return a +(b-a)*erf(x);
  return a + (b-a)*(1+erf(x/sqrt(2)))/2;
}


double get_trans_unif_r(double rz) {
  double rv = 2 * sin(M_PI * rz /6);
  return rv;
}

//' Generate Multivariate Uniform Data Follow the Given Correlation Structure.
//' @description 
//' This function implements a fast pseudo random number generator
//' for a multivariate uniform distribution where every marginal
//' distribution is \eqn{Unif(0,1)}.
//' @usage fastunif(rela_mat, row)
//' @param rela_mat The desired correlation matrix structure you want the generated data follow. This matrix must be positive definite.
//' @param row The observed sample size you want to generate.
//' @return A \eqn{row\times rela_mat.no} matrix of generated data.
//' @export 
//' @examples
//' A = ARStructure(0.9,5)
//' a = fastunif(A,50000)
// [[Rcpp::export]]
arma::mat fastunif(arma::mat rela_mat,int row) {
  // generate the base standard normal distribution
  arma::mat A = randn<arma::mat>(row, rela_mat.n_cols);
  // generate correlation matrix of V
  arma::mat Rv = ones(rela_mat.n_rows, rela_mat.n_cols);
  for (int f(0); f < int(Rv.n_rows); f++) {
    for (int g(f+1); g< int(Rv.n_cols); g++) {
      Rv(f,g) = get_trans_unif_r(rela_mat(f,g));
      Rv(g,f) = get_trans_unif_r(rela_mat(f,g));
    }
  }
  // Cholesky Decomposition on the Rv
  arma::mat L;
  chol(L, Rv);
  // Generate V
  arma::mat V = A*L;
  // Generate Z
  arma::mat Z = arma::mat(row, rela_mat.n_cols);
  for (int k(0); k<int(V.n_rows); k++) {
    for (int m(0); m< int(V.n_cols); m++) {
      Z(k,m) = get_h_unif(0,1,V(k,m));
    }
  }
  return Z;
}

double erfinv(double x) {
  double tt1, tt2, lnx, sgn;
  sgn = (x < 0) ? -1 : 1;
  
  x = (1 - x)*(1 + x);
  lnx = log(x);
  
  tt1 = 2/(M_PI*0.147) + 0.5 * lnx;
  tt2 = 1/(0.147) * lnx;
  
  return(sgn*sqrt(-tt1 + sqrt(tt1*tt1 - tt2)));
}

double get_trans_LN_r(double rz, double sigma) {
  double rv = log(rz*(exp(sigma*sigma)-1)+1)/(sigma*sigma);
  return rv;
}

double get_h_LN(double sigma, double mu, double x) {
  double Ninv = x;
  double LNinv = exp(sigma*Ninv+mu);
  return LNinv;
}


//' Generate Multivariate Logarithmic Normal Data Follow the Given Correlation Structure.
//' @description
//' This function implements a fast pseudo random number generator
//' for a multivariate logarithmic normal distribution where every marginal
//' distribution has equal variance.
//' @usage fastLN(rela_mat, row, mu, sigma)
//' @inheritParams fastunif
//' @param mu The mean vector you want the generated data follow. It must have the same dimensionality of the correlation matrix.
//' @param sigma The common marginal variance level. That is, we assume that the marginal distribution has identical variance.
//' @return A \eqn{row\times rela_mat.no} matrix of generated data.
//' @details
//' For \eqn{X_i\sim N(\mu,\sigma^2)}, we say \eqn{Y_i = e^{X_i}} follows a logarithmic normal
//' distribution. 
//' @export 
//' @examples
//' A = ARStructure(0.9,5)
//' mu = rep(0,5)
//' sigma = 1
//' a = fastLN(A,50000,mu,sigma)
// [[Rcpp::export]]
arma::mat fastLN(arma::mat rela_mat, int row, arma::vec mu, double sigma) {
  // generate the base standard normal distribution
  arma::mat A = arma::randn<arma::mat>(row, rela_mat.n_cols);
  // generate correlation matrix of V
  arma::mat Rv = ones(rela_mat.n_rows, rela_mat.n_cols);
  for (int f(0); f < int(Rv.n_rows); f++) {
    for (int g(f+1); g< int(Rv.n_cols); g++) {
      Rv(f,g) = get_trans_LN_r(rela_mat(f,g),sigma);
      Rv(g,f) = get_trans_LN_r(rela_mat(f,g),sigma);
    }
  }
  // Cholesky Decomposition on the Rv
  arma::mat L;
  chol(L, Rv);
  // Generate V
  arma::mat V = A*L;
  // Generate Z
  arma::mat Z = arma::mat(row, rela_mat.n_cols);
  for (int k(0); k<int(V.n_rows); k++) {
    for (int m(0); m< int(V.n_cols); m++) {
      Z(k,m) = get_h_LN(sigma,mu[m],V(k,m));
    }
  }
  return Z;
}

//' Generate Multivariate Exponential Data Follow the Given Correlation Structure.
//' @description
//' This function implements a fast pseudo random number generator
//' for a multivariate exponential distribution where every marginal
//' distribution has equal parameter \eqn{\lambda}.
//' @usage fastexp(rela_mat, lambda, row)
//' @inheritParams fastunif
//' @param lambda The parameter for the exponential distributions.
//' @return A \eqn{row\times rela_mat.no} matrix of generated data.
//' @details
//' If \eqn{X\sim Exp(\lambda)}, then its pdf is :
//' \deqn{f(x) = \lambda exp{-\lambda x},x>0}.
//' @export 
//' @examples
//' A = ARStructure(0.9,5)
//' lambda = 2
//' a = fastexp(A,lambda,50000)
// [[Rcpp::export]]
arma::mat fastexp(arma::mat rela_mat,double lambda,int row) {
  arma::mat V = fastunif(rela_mat,row);
  arma::mat W = (-1/lambda) * log(V);
  return W;
}

//' Generate Multivariate Beta Distribution Data Follow the Given Correlation Structure.
//' @description
//' This function implements a fast pseudo random number generator
//' for a multivariate beta distribution where every marginal
//' distribution is \eqn{Beta(\frac{1}{n},1)}
//' @usage fastbeta(rela_mat, n, row)
//' @inheritParams fastunif
//' @param n is a parameter of beta distribution. See detail.
//' @return A \eqn{row\times rela_mat.no} matrix of generated data.
//' @export 
//' @examples
//' A = ARStructure(0.9,5)
//' n = 1/5
//' a = fastbeta(A,n,50000)
// [[Rcpp::export]]
arma::mat fastbeta(arma::mat rela_mat,double n,int row) {
  arma::mat V1 = fastunif(rela_mat,row);
  arma::mat W1 = pow(V1,n);
  return W1;
}

//' Generate a Correlation Matrix that has AR Structure.
//' @description
//' This function generates a correlation matrix that has an autoregressive structure. That is,
//' \eqn{R = (r_{ij})_{n\times n}}, wehere \eqn{r_{ij} = \rho^{|i-j|}}.
//' @usage ARStructure(rho,d)
//' @param rho This is the basis autocorrelation coefficient we implement in the correlation matrix.
//' @param d This is the dimensionality of our correlation matrix.
//' @return A \eqn{d\times d} AR structure correlation matrix.
//' @export 
//' 
//' @examples
//' A = ARStructure(0.9,5)
// [[Rcpp::export]]
arma::mat ARStructure(double rho, int d) {
  arma::mat R = ones(d,d);
  for (int w(0); w<d; w++){
    for (int v(w+1);  v<d; v++){
      R(w,v) = pow(rho,v-w);
      R(v,w) = pow(rho,v-w);
    }
  }
  return R;
}

